package dao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import entity.Apartment;
import entity.ApartmentXML;
import utils.FileUtils;
 

public class ApartmentDao {
    public static final String APARTMENT_FILE_NAME = "apartment.xml";
    
    private List<Apartment> listApartments;
 
    public ApartmentDao() {
        this.listApartments = readListApartments();
        if (listApartments == null) {
        	listApartments = new ArrayList<Apartment>();
        }
    }
 
    
    
    public void writeListApartments(List<Apartment> apartments) {
        ApartmentXML apartmentXML = new ApartmentXML();
        apartmentXML.setApartment(apartments);
        FileUtils.writeXMLtoFile(APARTMENT_FILE_NAME, apartmentXML);
    }
    
    
 
    
    
    public List<Apartment> readListApartments() {
        List<Apartment> list = new ArrayList<Apartment>();
        ApartmentXML apartmentXML = (ApartmentXML) FileUtils.readXMLFile(
                APARTMENT_FILE_NAME, ApartmentXML.class);
        if (apartmentXML != null) {
            list = apartmentXML.getApartment();
        }
        return list;
    }
    
    // thêm 
    public void add(Apartment apartment) {
        listApartments.add(apartment);
        writeListApartments(listApartments);
    }
    
    // sửa 
    
    
    public void edit(Apartment apartment) {
        this.listApartments.remove(apartment);
        this.listApartments.add(apartment);
        writeListApartments(listApartments);
    }
    
    public void delete(Apartment apartment) {
    	this.listApartments.remove(apartment);
    	writeListApartments(listApartments);
    }
    public int getTongSoCanHo() {
        return listApartments.size();
    }
    
    public double getTongGiaThue() {
        return listApartments.stream()
            .mapToDouble(Apartment::getGiaTien)
            .sum();
    }
    
    public double getGiaThueMax() {
        return listApartments.stream()
            .mapToDouble(Apartment::getGiaTien)
            .max()
            .orElse(0);
    }
    
    public double getGiaThueMin() {
        return listApartments.stream()
            .mapToDouble(Apartment::getGiaTien)
            .min()
            .orElse(0);
    }
    
    public int getSoCanHoCon() {
        return (int) listApartments.stream()
            .filter(Apartment::isTinhTrang)
            .count();
    }
    
    public int getSoCanHoHet() {
        return (int) listApartments.stream()
            .filter(a -> !a.isTinhTrang())
            .count();
    }
    
    public Map<String, Integer> thongKeDichVu() {
        Map<String, Integer> dichVuCount = new HashMap<>();
        for (Apartment apartment : listApartments) {
            String dichVu = apartment.getLuaChon_dichVu();
            dichVuCount.put(dichVu, dichVuCount.getOrDefault(dichVu, 0) + 1);
        }
        return dichVuCount;
    }
    
    public Apartment findId(int toaNhaId) {
        for (Apartment apartment : listApartments) {
            if (apartment.getToaNha() == toaNhaId) {
                return apartment;
            }
        }
        return null; 
    }
    
    
    public void sortApartmentByDienTich() {
        Collections.sort(listApartments, new Comparator<Apartment>() {
            public int compare(Apartment apartment1, Apartment apartment2) {
                return Double.compare(apartment1.getDienTich(), apartment2.getDienTich());
            }
        });
    }
    public void sortApartmentByGiaTien() {
        Collections.sort(listApartments, new Comparator<Apartment>() {
            @Override
            public int compare(Apartment a1, Apartment a2) {
                return Double.compare(a1.getGiaTien(), a2.getGiaTien()); 
            }
        });
    }
    

    public List<Apartment> searchByString(String keyword) {
        return listApartments.stream()
            .filter(apartment -> 
                apartment.getCanHo().toLowerCase().contains(keyword.toLowerCase()) ||
                apartment.getThongTinNguoiThue().toLowerCase().contains(keyword.toLowerCase()))
            .collect(Collectors.toList());
    }

    public List<Apartment> searchByDienTich(double minDienTich, double maxDienTich) {
        return listApartments.stream()
            .filter(apartment -> 
                apartment.getDienTich() >= minDienTich && 
                apartment.getDienTich() <= maxDienTich)
            .collect(Collectors.toList());
    }

    public List<Apartment> searchByGiaTien(double minGiaTien, double maxGiaTien) {
        return listApartments.stream()
            .filter(apartment -> 
                apartment.getGiaTien() >= minGiaTien && 
                apartment.getGiaTien() <= maxGiaTien)
            .collect(Collectors.toList());
    }
    
    
    
  
 
    
 
    
    
 
    public List<Apartment> getListApartments() {
        return listApartments;
    }
 
    public void setListApartments(List<Apartment> listApartments) {
        this.listApartments = listApartments;
    }
}
