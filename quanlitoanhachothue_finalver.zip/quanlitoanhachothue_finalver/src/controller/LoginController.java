package controller;
 
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import dao.UserDao;
import entity.User;
import view.ApartmentView;
import view.LoginView;

 
public class LoginController {
    private UserDao userDao;
    private LoginView loginView;
    private ApartmentView apartmentView;
     
    public LoginController(LoginView view) {
        this.loginView = view;
        this.userDao = new UserDao();
        view.addLoginListener(new LoginListener());
        loginView.setVisible(true);
    }
    
    
     
    public void showLoginView() {
    	loginView.setLocationRelativeTo(null);
        loginView.setVisible(true);
    }
     
    /**
     * Lớp LoginListener 
     * chứa cài đặt cho sự kiện click button "Login"
     * 
     * 
     */
    class LoginListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            User user = loginView.getUser();
            if (userDao.checkUser(user)) {
                
                apartmentView = new ApartmentView();
                ApartmentController apartmentController = new ApartmentController(apartmentView);
                JOptionPane.showMessageDialog(loginView, "Đăng nhập thành công");
//                
                loginView.setVisible(false);
                apartmentView.setVisible(true);
            } else {
                loginView.showMessage("username hoặc password không đúng.");
            }
        }
    }
}