package controller;
 
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
 
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
 
import dao.ApartmentDao;
import entity.Apartment;
import view.ApartmentView;
 
public class ApartmentController {
	public ApartmentDao apartmentDao;
	public ApartmentView apartmentView;
	
	
	public ApartmentController(ApartmentView view) {
		this.apartmentView = view;
		apartmentDao = new ApartmentDao();
	}


	
	
	
	
	
	
	
	
}