package view;

import java.awt.EventQueue;
import java.awt.Font;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import entity.User;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.AbstractButton;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
public class LoginView extends JFrame implements ActionListener {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JPasswordField passwordField;
    private JButton loginBtn;
    private JLabel userNameLabel;
    private JLabel passwordLabel;
    private JTextField userNameField;
	public ApartmentView apartmentView;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    LoginView frame = new LoginView();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public LoginView() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 450, 300); // Thiết lập kích thước và vị trí cho JFrame

        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setLayout(null); // Sử dụng null layout
        setContentPane(contentPane);

        userNameLabel = new JLabel("UserName");
        userNameLabel.setBounds(100, 80, 100, 30); // Set vị trí và kích thước cho label
        contentPane.add(userNameLabel);

        userNameField = new JTextField();
        userNameField.setBounds(200, 80, 150, 30); // Set vị trí và kích thước cho textField
        contentPane.add(userNameField);

        passwordLabel = new JLabel("Password");
        passwordLabel.setBounds(100, 130, 100, 30); // Set vị trí và kích thước cho label
        contentPane.add(passwordLabel);

        passwordField = new JPasswordField();
        passwordField.setBounds(200, 130, 150, 30); // Set vị trí và kích thước cho passwordField
        contentPane.add(passwordField);

        loginBtn = new JButton("Login");
        loginBtn.setBounds(222, 184, 100, 30); // Set vị trí và kích thước cho nút login
        loginBtn.addActionListener(this);
        contentPane.add(loginBtn);

        setTitle("Login");
        setResizable(false);
        
    }
    public void showMessage(String message) {
        JOptionPane.showMessageDialog(this, message);
    }
 
    public User getUser() {
    	String username = userNameField.getText();
        String password = new String(passwordField.getPassword());
        return new User(username, password);
    }
 
    
     
    public void addLoginListener(ActionListener listener) {
        loginBtn.addActionListener(listener);
    }

	@Override
	public void actionPerformed(ActionEvent e) {
		 
        User user = getUser();
       
        if (user.getUserName().isEmpty() || user.getPassword().isEmpty()) {
            showMessage("Vui lòng nhập tên đăng nhập và mật khẩu.");
        } else {
            
//            showMessage("Đăng nhập thành công!");
            
        }
		
	}
    
   
}
