package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JFileChooser;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.Locale;
import java.util.stream.Collectors;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;
import javax.swing.JDialog;
import java.awt.GridLayout;
import java.util.Map;
import javax.swing.AbstractButton;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SpringLayout;
import javax.swing.WindowConstants;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

import dao.ApartmentDao;
import entity.Apartment;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import java.awt.Font;
import javax.swing.JRadioButton;

import java.awt.BorderLayout;
import java.awt.Component;
public class ApartmentView extends JFrame implements ActionListener, ListSelectionListener  {
	
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField idField;
	private JLabel CanHoLabel;
	private JTextField field_CanHo;
	private JTextField field_DienTich;
	private JCheckBox tiVi_checkbox;
	private JCheckBox maySuoi_checkbox;
	private JLabel DVTienichLabel;
	private JCheckBox donDep_checkbox;
	private JCheckBox internet_checkbox;
	private JCheckBox trongTre_checkBox;
	private JCheckBox gym_checkBox;
	private JLabel NguoiThueLabel;
	private JTextField textField;
	private JLabel lblNewLabel_1;
	private JTextField textField_1;
	private JTable tabelModel;
	private JButton btn_Add;
	private JButton btn_edit;
	private JButton btn_clear;
	private JButton btn_remove;
	
	
	private DefaultTableModel tableModel;
	private ApartmentDao apartmentDao = new ApartmentDao();
	private JRadioButton rdbtnAvailable;
	private JRadioButton rdbtnNotAvailable;
	private JTable table;
	private ButtonGroup buttonGroup_tinhTrang;
	private JCheckBox dieuHoa_checkBox;
	private JCheckBox nongLanh_checkBox;
	private JComboBox<String> comboBoxDichVuTienIch;
	private NumberFormat numberFormat;
	private JTextField textField_timKiem;
	private JButton btnThongKe;
	private JButton btn_xuatpdf;
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ApartmentView frame = new ApartmentView();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ApartmentView() {
		setTitle("Quản lí nhà cho thuê");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1296, 625);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		numberFormat = NumberFormat.getInstance(new Locale("vi", "VN")); 
		numberFormat.setGroupingUsed(true);
		JLabel idLabel = new JLabel("Toà nhà");
		idLabel.setFont(new Font("Tahoma", Font.BOLD, 11));
		idLabel.setBounds(10, 11, 57, 23);
		contentPane.add(idLabel);
		
		idField = new JTextField();
		idField.setBounds(78, 12, 145, 20);
		contentPane.add(idField);
		idField.setColumns(10);
		
		CanHoLabel = new JLabel("Căn hộ");
		CanHoLabel.setFont(new Font("Tahoma", Font.BOLD, 11));
		CanHoLabel.setBounds(10, 45, 57, 23);
		contentPane.add(CanHoLabel);
		
		field_CanHo = new JTextField();
		field_CanHo.setBounds(78, 46, 145, 20);
		contentPane.add(field_CanHo);
		field_CanHo.setColumns(10);
		
		JLabel DienTichLabel = new JLabel("Diện tích");
		DienTichLabel.setFont(new Font("Tahoma", Font.BOLD, 11));
		DienTichLabel.setBounds(10, 79, 57, 14);
		contentPane.add(DienTichLabel);
		
		field_DienTich = new JTextField();
		field_DienTich.setBounds(78, 77, 145, 20);
		contentPane.add(field_DienTich);
		field_DienTich.setColumns(10);
		
		JLabel tienNghiLabel = new JLabel("Tiện nghi");
		tienNghiLabel.setFont(new Font("Tahoma", Font.BOLD, 11));
		tienNghiLabel.setBounds(10, 115, 57, 14);
		contentPane.add(tienNghiLabel);
		
		dieuHoa_checkBox = new JCheckBox("Điều hoà");
		dieuHoa_checkBox.setBounds(78, 111, 97, 23);
		contentPane.add(dieuHoa_checkBox);
		
		 nongLanh_checkBox = new JCheckBox("Nóng lạnh");
		nongLanh_checkBox.setBounds(177, 111, 97, 23);
		contentPane.add(nongLanh_checkBox);
		
		tiVi_checkbox = new JCheckBox("Tivi");
		tiVi_checkbox.setBounds(78, 146, 97, 23);
		contentPane.add(tiVi_checkbox);
		
		maySuoi_checkbox = new JCheckBox("Máy sưởi");
		maySuoi_checkbox.setBounds(177, 146, 97, 23);
		contentPane.add(maySuoi_checkbox);


		
		DVTienichLabel = new JLabel("Dịch vụ tiện ích đi kèm");
		DVTienichLabel.setFont(new Font("Tahoma", Font.BOLD, 11));
		DVTienichLabel.setBounds(10, 186, 139, 14);
		contentPane.add(DVTienichLabel);
		
		
		 this.comboBoxDichVuTienIch = new JComboBox<>();
		 this.comboBoxDichVuTienIch.setBounds(54, 211, 200, 23);
		 this.comboBoxDichVuTienIch.addItem("");
		 this.comboBoxDichVuTienIch.addItem("Dịch vụ dọn dẹp định kỳ");
		 this.comboBoxDichVuTienIch.addItem("Dịch vụ Wifi Internet");
		 this.comboBoxDichVuTienIch.addItem("Dịch vụ trông trẻ");
		 this.comboBoxDichVuTienIch.addItem("Phòng Gym");
		 contentPane.add(this.comboBoxDichVuTienIch);

		
		NguoiThueLabel = new JLabel("Thông tin người thuê");
		NguoiThueLabel.setFont(new Font("Tahoma", Font.BOLD, 11));
		NguoiThueLabel.setBounds(10, 370, 118, 23);
		contentPane.add(NguoiThueLabel);
		
		textField = new JTextField();
		textField.setBounds(10, 400, 213, 36);
		contentPane.add(textField);
		textField.setColumns(10);
		
		lblNewLabel_1 = new JLabel("Giá thuê");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_1.setBounds(10, 333, 57, 14);
		contentPane.add(lblNewLabel_1);
		
		textField_1 = new JTextField();
		textField_1.setBounds(78, 327, 145, 20);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		 rdbtnAvailable = new JRadioButton("Còn");
		rdbtnAvailable.setBounds(78, 443, 57, 23);
		contentPane.add(rdbtnAvailable);
		
		 rdbtnNotAvailable = new JRadioButton("Hết");
		rdbtnNotAvailable.setBounds(151, 443, 57, 23);
		contentPane.add(rdbtnNotAvailable);
		
		JLabel lblNewLabel_2 = new JLabel("Tình trạng");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_2.setBounds(10, 447, 67, 14);
		contentPane.add(lblNewLabel_2);
		
		buttonGroup_tinhTrang = new ButtonGroup();
		buttonGroup_tinhTrang.add(rdbtnAvailable);
		buttonGroup_tinhTrang.add(rdbtnNotAvailable);

		
		btn_Add = new JButton("Thêm");
		btn_Add.setBounds(10, 483, 90, 32);
		contentPane.add(btn_Add);
		
		btn_edit = new JButton("Sửa");
		
		btn_edit.setBounds(133, 483, 90, 32);
		contentPane.add(btn_edit);
		
		btn_clear = new JButton("Xóa tất cả");
		btn_clear.setFont(new Font("Tahoma", Font.PLAIN, 10));
		btn_clear.setBounds(133, 524, 90, 32);
		contentPane.add(btn_clear);
		
		btn_remove = new JButton("Xóa");
		
		btn_remove.setBounds(10, 524, 90, 32);
		contentPane.add(btn_remove);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(282, 27, 986, 434);
		contentPane.add(scrollPane);
		
		
		
		
		table = new JTable();
		
		scrollPane.setViewportView(table);
		btn_Add.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					addApartment();
				} catch (ParseException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		tableModel = new DefaultTableModel(
			    new Object[][] {},
			    new String[] {
			        "Tòa nhà", "Căn hộ", "Diện tích m2", "Tiện nghi", "Dịch vụ tiện ích đi kèm", "Giá thuê (vnd)", "Thông tin người thuê", "Tình trạng"
			    }
			);
		
			table.setModel(tableModel); 
			
			JLabel lblNewLabel = new JLabel("m2");
			lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 11));
			lblNewLabel.setBounds(238, 79, 46, 14);
			contentPane.add(lblNewLabel);
			
			JLabel lblNewLabel_3 = new JLabel("Tìm kiếm");
			lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 14));
			lblNewLabel_3.setBounds(282, 492, 75, 14);
			contentPane.add(lblNewLabel_3);
			
			JButton btnTimKiem = new JButton("Tìm");
			btnTimKiem.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
				}
			});
			btnTimKiem.setFont(new Font("Tahoma", Font.BOLD, 14));
			btnTimKiem.setBounds(459, 486, 89, 23);
			contentPane.add(btnTimKiem);
			
			JLabel lblNewLabel_4 = new JLabel("Sắp xếp theo giá");
			lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 14));
			lblNewLabel_4.setBounds(698, 486, 132, 23);
			contentPane.add(lblNewLabel_4);
			
			JButton btn_SapXep_Tang = new JButton("Tăng");
			btn_SapXep_Tang.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
				}
			});
			btn_SapXep_Tang.setBounds(840, 488, 89, 23);
			contentPane.add(btn_SapXep_Tang);
			
			JButton btn_SapXep_Giam = new JButton("Giảm");
			btn_SapXep_Giam.setBounds(941, 488, 89, 23);
			contentPane.add(btn_SapXep_Giam);
			
			textField_timKiem = new JTextField();
			textField_timKiem.setBounds(367, 489, 86, 20);
			contentPane.add(textField_timKiem);
			textField_timKiem.setColumns(10);
			
			JButton btn_HuyTim = new JButton("Hủy tìm");
			btn_HuyTim.setFont(new Font("Tahoma", Font.BOLD, 14));
			btn_HuyTim.setBounds(558, 486, 86, 23);
			contentPane.add(btn_HuyTim);
			
			btnThongKe = new JButton("Thống kê");
			btnThongKe.setBounds(282, 529, 89, 23);
			contentPane.add(btnThongKe);
			
			btn_xuatpdf = new JButton("Xuất PDF");
			btn_xuatpdf.setBounds(377, 529, 89, 23);
			contentPane.add(btn_xuatpdf);
			table.getSelectionModel().addListSelectionListener(this);
			table.getColumnModel().getColumn(0).setPreferredWidth(70); // Tòa nhà
			table.getColumnModel().getColumn(1).setPreferredWidth(70); // Căn hộ
			table.getColumnModel().getColumn(2).setPreferredWidth(100); // Diện tích
			table.getColumnModel().getColumn(3).setPreferredWidth(200); // Tiện nghi
			table.getColumnModel().getColumn(4).setPreferredWidth(200); // Dịch vụ tiện ích
			table.getColumnModel().getColumn(5).setPreferredWidth(100); // Giá thuê
			table.getColumnModel().getColumn(6).setPreferredWidth(150); // Thông tin người thuê
			table.getColumnModel().getColumn(7).setPreferredWidth(70);
			
			
	    btn_edit.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				editApartment();
				
			}
		});
	    btn_remove.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				removeApartment();
				
			}
		});
	    btn_clear.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				 removeAllApartments();
				
			}
		});
	    
	    btn_SapXep_Tang.addActionListener(new ActionListener() {
	        public void actionPerformed(ActionEvent e) {
	            apartmentDao.sortApartmentByGiaTien(); // sxep tăng
	            loadDataToTable();
	        }
	    });

	    
	    btn_SapXep_Giam.addActionListener(new ActionListener() {
	        public void actionPerformed(ActionEvent e) {
	            
	            List<Apartment> apartments = apartmentDao.getListApartments();
	            apartments.sort((a1, a2) -> Double.compare(a2.getGiaTien(), a1.getGiaTien())); // sxep giam
	            apartmentDao.setListApartments(apartments); 
	            loadDataToTable(); 
	        }
	    });
	    
	    btnTimKiem.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				performSearch();
			}
		});
	    btn_HuyTim.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				resetSearch();
				
			}
		});
	    
	    btnThongKe.addActionListener(new ActionListener() {
	        @Override
	        public void actionPerformed(ActionEvent e) {
	        	performStatistics();
	        }
	    });
	    btn_xuatpdf.addActionListener(new ActionListener() {
	        @Override
	        public void actionPerformed(ActionEvent e) {
	        	exportToPDF();
	        }
	    });
		loadDataToTable();
	}
	
	private void loadDataToTable() {
	    tableModel.setRowCount(0); 
	    List<Apartment> apartments = apartmentDao.getListApartments();
	    for (Apartment apartment : apartments) {
	        tableModel.addRow(new Object[] {
	            apartment.getToaNha(), apartment.getCanHo(), numberFormat.format(apartment.getDienTich() ),
	            apartment.getLuaChon_tienIch(), apartment.getLuaChon_dichVu() != null ? apartment.getLuaChon_dichVu() : "", 
	            numberFormat.format(apartment.getGiaTien()), apartment.getThongTinNguoiThue(),
	            apartment.isTinhTrang() ? "Còn" : "Hết"
	        });
	    }
	}



	@Override
	public void valueChanged(ListSelectionEvent e) {
		if (!e.getValueIsAdjusting()) {
            int selectedRow = table.getSelectedRow();
            if (selectedRow >= 0) {
                // cập nhật trường khi chọn
                idField.setText(tableModel.getValueAt(selectedRow, 0).toString());
                field_CanHo.setText(tableModel.getValueAt(selectedRow, 1).toString());
                field_DienTich.setText(tableModel.getValueAt(selectedRow, 2).toString());
                textField_1.setText(tableModel.getValueAt(selectedRow, 5).toString());
                textField.setText(tableModel.getValueAt(selectedRow, 6).toString());

                // checbox cho tienich
                String tienIch = tableModel.getValueAt(selectedRow, 3).toString();
                dieuHoa_checkBox.setSelected(tienIch.contains("Điều hoà"));
                nongLanh_checkBox.setSelected(tienIch.contains("Nóng lạnh"));
                tiVi_checkbox.setSelected(tienIch.contains("Tivi"));
                maySuoi_checkbox.setSelected(tienIch.contains("Máy sưởi"));
                // capnhat dropdown dichvu
                
                String dichVu = tableModel.getValueAt(selectedRow, 4).toString();
                comboBoxDichVuTienIch.setSelectedItem(dichVu);
                
                String tinhTrang = tableModel.getValueAt(selectedRow, 7).toString();
                if (tinhTrang.equals("Còn")) {
                    rdbtnAvailable.setSelected(true);
                } else {
                    rdbtnNotAvailable.setSelected(true);
                }
            }
        }
	}
	 private void addApartment() throws ParseException {

		 if (idField.getText().isEmpty() || field_CanHo.getText().isEmpty() || field_DienTich.getText().isEmpty() ||
			        textField_1.getText().isEmpty() || textField.getText().isEmpty() ||
			        (!tiVi_checkbox.isSelected() && !maySuoi_checkbox.isSelected() && 
			        		comboBoxDichVuTienIch.getSelectedIndex() == 0)) {
			        
			        JOptionPane.showMessageDialog(this, "Vui lòng nhập đầy đủ thông tin và chọn ít nhất một tiện ích hoặc dịch vụ.", "Thông báo", JOptionPane.WARNING_MESSAGE);
			        return; 
			    }

			    // Kiểm tra ID trùng lặp
			    int newToaNhaId = Integer.parseInt(idField.getText());
			    double dienTich = Double.parseDouble(field_DienTich.getText());
		        double giaTien = numberFormat.parse(textField_1.getText()).doubleValue();
			    List<Apartment> apartments = apartmentDao.getListApartments();
			    for (Apartment apartment : apartments) {
			        if (apartment.getToaNha() == newToaNhaId) {
			            JOptionPane.showMessageDialog(this, "ID của tòa nhà đã tồn tại. Vui lòng nhập ID khác.", "Thông báo", JOptionPane.WARNING_MESSAGE);
			            return;
			        }
			    }

			    Apartment apartment = createApartmentFromFields();
			    apartmentDao.add(apartment);
			    loadDataToTable();
			    clearFields();
		 
		 
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btn_Add) {
            try {
				addApartment();
			} catch (ParseException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		
	}   
     else if (e.getSource() == btn_clear) {
    	 removeAllApartments();
    }
	}

	
	private void editApartment() {
	    try {
	        int selectedRow = table.getSelectedRow();
	        if (selectedRow < 0) {
	            JOptionPane.showMessageDialog(this, 
	                "Vui lòng chọn một căn hộ để sửa.", 
	                "Thông báo", 
	                JOptionPane.WARNING_MESSAGE);
	            return;
	        }

	        // Lấy ID của dòng được chọn
	        int toaNha = Integer.parseInt(tableModel.getValueAt(selectedRow, 0).toString());
	        
	        // Tìm căn hộ cần sửa
	        Apartment apartmentToEdit = apartmentDao.findId(toaNha);

	        if (apartmentToEdit != null) {
	            // Parse và cập nhật các giá trị
	            apartmentToEdit.setCanHo(field_CanHo.getText());
	            apartmentToEdit.setDienTich(Double.parseDouble(field_DienTich.getText()));
	            
	            // Parse giá tiền
	            double giaTien = numberFormat.parse(textField_1.getText()).doubleValue();
	            apartmentToEdit.setGiaTien(giaTien);

	            // Cập nhật tiện ích
	            String luaChon_tienIch = "";
	            if (dieuHoa_checkBox.isSelected()) luaChon_tienIch += "Điều hoà, ";
	            if (nongLanh_checkBox.isSelected()) luaChon_tienIch += "Nóng lạnh, ";
	            if (tiVi_checkbox.isSelected()) luaChon_tienIch += "Tivi, ";
	            if (maySuoi_checkbox.isSelected()) luaChon_tienIch += "Máy sưởi, ";

	            if (!luaChon_tienIch.isEmpty()) {
	                luaChon_tienIch = luaChon_tienIch.substring(0, luaChon_tienIch.length() - 2);
	            }
	            apartmentToEdit.setLuaChon_tienIch(luaChon_tienIch);

	            // Cập nhật các trường khác
	            apartmentToEdit.setLuaChon_dichVu((String) comboBoxDichVuTienIch.getSelectedItem());
	            apartmentToEdit.setThongTinNguoiThue(textField.getText());
	            apartmentToEdit.setTinhTrang(rdbtnAvailable.isSelected());

	            // Gọi phương thức sửa trong DAO
	            apartmentDao.edit(apartmentToEdit);

	            // Cập nhật lại dữ liệu trong bảng 
	            // Thay vì load lại toàn bộ, chúng ta sẽ cập nhật trực tiếp dòng đang chọn
	            tableModel.setValueAt(apartmentToEdit.getCanHo(), selectedRow, 1);
	            tableModel.setValueAt(numberFormat.format(apartmentToEdit.getDienTich()), selectedRow, 2);
	            tableModel.setValueAt(luaChon_tienIch, selectedRow, 3);
	            tableModel.setValueAt(apartmentToEdit.getLuaChon_dichVu(), selectedRow, 4);
	            tableModel.setValueAt(numberFormat.format(apartmentToEdit.getGiaTien()), selectedRow, 5);
	            tableModel.setValueAt(apartmentToEdit.getThongTinNguoiThue(), selectedRow, 6);
	            tableModel.setValueAt(apartmentToEdit.isTinhTrang() ? "Còn" : "Hết", selectedRow, 7);

	            // Xóa các trường nhập
	            clearFields();
	        } else {
	            JOptionPane.showMessageDialog(this, 
	                "Không tìm thấy căn hộ để chỉnh sửa.", 
	                "Lỗi", 
	                JOptionPane.ERROR_MESSAGE);
	        }
	    } catch (NumberFormatException e) {
	        JOptionPane.showMessageDialog(this, 
	            "Định dạng số không hợp lệ. Vui lòng kiểm tra lại.", 
	            "Lỗi", 
	            JOptionPane.ERROR_MESSAGE);
	    } catch (ParseException e) {
	        JOptionPane.showMessageDialog(this, 
	            "Lỗi định dạng tiền tệ. Vui lòng nhập số theo định dạng chính xác.", 
	            "Lỗi", 
	            JOptionPane.ERROR_MESSAGE);
	    }
	}

	 
	 
	 
	 private void removeApartment() {
	    int selectedRow = table.getSelectedRow();
	    if (selectedRow >= 0) {
	        // Hiển thị hộp thoại xác nhận
	        int confirm = JOptionPane.showConfirmDialog(
	            this, 
	            "Bạn có chắc chắn muốn xóa căn hộ này?", 
	            "Xác nhận xóa", 
	            JOptionPane.YES_NO_OPTION
	        );
	        
	        if (confirm == JOptionPane.YES_OPTION) {
	            try {
	                // Lấy ID của tòa nhà từ hàng được chọn
	                int toaNha = Integer.parseInt(tableModel.getValueAt(selectedRow, 0).toString());
	                
	                // Tìm và xóa căn hộ
	                Apartment apartmentToRemove = apartmentDao.findId(toaNha);
	                
	                if (apartmentToRemove != null) {
	                    apartmentDao.delete(apartmentToRemove);
	                    
	                    // Cập nhật bảng
	                    loadDataToTable();
	                    clearFields();
	                    
	                    JOptionPane.showMessageDialog(
	                        this, 
	                        "Đã xóa căn hộ thành công.", 
	                        "Thông báo", 
	                        JOptionPane.INFORMATION_MESSAGE
	                    );
	                } else {
	                    JOptionPane.showMessageDialog(
	                        this, 
	                        "Không tìm thấy căn hộ để xóa.", 
	                        "Lỗi", 
	                        JOptionPane.ERROR_MESSAGE
	                    );
	                }
	            } catch (Exception e) {
	                JOptionPane.showMessageDialog(
	                    this, 
	                    "Lỗi khi xóa căn hộ: " + e.getMessage(), 
	                    "Lỗi", 
	                    JOptionPane.ERROR_MESSAGE
	                );
	            }
	        }
	    } else {
	        JOptionPane.showMessageDialog(
	            this, 
	            "Vui lòng chọn một căn hộ để xóa.", 
	            "Thông báo", 
	            JOptionPane.WARNING_MESSAGE
	        );
	    }
	}
		private void clearFields() {
	        idField.setText("");
	        field_CanHo.setText("");
	        field_DienTich.setText("");
	        textField.setText("");
	        textField_1.setText("");
	        dieuHoa_checkBox.setSelected(false);
	        nongLanh_checkBox.setSelected(false);
	        tiVi_checkbox.setSelected(false);
	        maySuoi_checkbox.setSelected(false);
	        comboBoxDichVuTienIch.setSelectedIndex(0); 
	        rdbtnAvailable.setSelected(false);
	        rdbtnNotAvailable.setSelected(false);
	        table.clearSelection();
	    }
		
		private Apartment createApartmentFromFields() throws ParseException {
	        int toaNha = Integer.parseInt(idField.getText());
	        String canHo = field_CanHo.getText();
	        double dienTich = numberFormat.parse(field_DienTich.getText()).doubleValue();
	        
	        
	        String luaChon_tienIch = "";
	        if (dieuHoa_checkBox.isSelected()) luaChon_tienIch += "Điều hoà, ";
	        if (nongLanh_checkBox.isSelected()) luaChon_tienIch += "Nóng lạnh, ";
	        if (tiVi_checkbox.isSelected()) luaChon_tienIch += "Tivi, ";
	        if (maySuoi_checkbox.isSelected()) luaChon_tienIch += "Máy sưởi, ";

	        String luaChon_dichVu = (String) comboBoxDichVuTienIch.getSelectedItem();
	        if (luaChon_dichVu == null || luaChon_dichVu.isEmpty()) {
	            luaChon_dichVu = "";
	        }
	        
	        if (!luaChon_tienIch.isEmpty()) luaChon_tienIch = luaChon_tienIch.substring(0, luaChon_tienIch.length() - 2);
	        
	        double giaTien = Double.parseDouble(textField_1.getText());
	        String thongTinNguoiThue = textField.getText();
	        boolean tinhTrang = rdbtnAvailable.isSelected();
	        return new Apartment(toaNha, canHo, dienTich, luaChon_tienIch, luaChon_dichVu, giaTien, thongTinNguoiThue, tinhTrang);
	    }
	
		private void removeAllApartments() {
		    
		    int confirm = JOptionPane.showConfirmDialog(
		        this, 
		        "Bạn có chắc chắn muốn xóa tất cả dữ liệu?", 
		        "Xác nhận xóa", 
		        JOptionPane.YES_NO_OPTION
		    );
		    
		    if (confirm == JOptionPane.YES_OPTION) {
		        apartmentDao.getListApartments().clear();
		        loadDataToTable();
		        clearFields();
		        JOptionPane.showMessageDialog(
		            this, 
		            "Đã xóa tất cả dữ liệu.", 
		            "Thông báo", 
		            JOptionPane.INFORMATION_MESSAGE
		        );
		    }
		}
		
		// chuc năng tìm kiem
		private void performSearch() {
		    String keyword = textField_timKiem.getText().trim();
		    
		    if (keyword.isEmpty()) {
		        JOptionPane.showMessageDialog(this, "Vui lòng nhập từ khóa tìm kiếm");
		        return;
		    }

		    List<Apartment> searchResults = new ArrayList<>();

		    try {
		       
		        double searchNumber = Double.parseDouble(keyword);
		        
		        
		        searchResults = apartmentDao.getListApartments().stream()
		            .filter(apartment -> 
		                apartment.getToaNha() == searchNumber ||
		                apartment.getDienTich() == searchNumber ||
		                apartment.getGiaTien() == searchNumber)
		            .collect(Collectors.toList());
		    } catch (NumberFormatException e) {
		       
		        searchResults = apartmentDao.getListApartments().stream()
		            .filter(apartment -> 
		                apartment.getCanHo().toLowerCase().contains(keyword.toLowerCase()) ||
		                apartment.getLuaChon_tienIch().toLowerCase().contains(keyword.toLowerCase()) ||
		                apartment.getLuaChon_dichVu().toLowerCase().contains(keyword.toLowerCase()) ||
		                apartment.getThongTinNguoiThue().toLowerCase().contains(keyword.toLowerCase()))
		            .collect(Collectors.toList());
		    }

		    if (searchResults.isEmpty()) {
		        JOptionPane.showMessageDialog(this, "Không tìm thấy kết quả phù hợp");
		    } else {
		        
		        tableModel.setRowCount(0);
		        
		        
		        for (Apartment apartment : searchResults) {
		            tableModel.addRow(new Object[] {
		                apartment.getToaNha(), 
		                apartment.getCanHo(), 
		                numberFormat.format(apartment.getDienTich()),
		                apartment.getLuaChon_tienIch(), 
		                apartment.getLuaChon_dichVu() != null ? apartment.getLuaChon_dichVu() : "", 
		                numberFormat.format(apartment.getGiaTien()), 
		                apartment.getThongTinNguoiThue(),
		                apartment.isTinhTrang() ? "Còn" : "Hết"
		            });
		        }
		    }
		}

		
		private void resetSearch() {
		    loadDataToTable();
		}
		
		private void performStatistics() {
		    List<Apartment> apartments = apartmentDao.getListApartments();
		    
		    if (apartments.isEmpty()) {
		        JOptionPane.showMessageDialog(this, "Không có dữ liệu để thống kê");
		        return;
		    }

		    // Tính toán các chỉ số thống kê
		    int totalApartments = apartments.size();
		    int availableApartments = (int) apartments.stream().filter(Apartment::isTinhTrang).count();
		    int unavailableApartments = totalApartments - availableApartments;
		    
		    double totalRent = apartments.stream()
		        .mapToDouble(Apartment::getGiaTien)
		        .sum();
		    
		    double avgRent = totalRent / totalApartments;
		    
		    double maxRent = apartments.stream()
		        .mapToDouble(Apartment::getGiaTien)
		        .max()
		        .orElse(0);
		    
		    double minRent = apartments.stream()
		        .mapToDouble(Apartment::getGiaTien)
		        .min()
		        .orElse(0);

		    // Tạo dialog để hiển thị thống kê
		    JDialog statisticsDialog = new JDialog(this, "Thống kê căn hộ", true);
		    statisticsDialog.setSize(800, 600);
		    statisticsDialog.setLayout(new BorderLayout());

		    // Panel thông tin thống kê
		    JPanel infoPanel = new JPanel();
		    infoPanel.setLayout(new BoxLayout(infoPanel, BoxLayout.Y_AXIS));
		    infoPanel.add(new JLabel("Tổng số căn hộ: " + totalApartments));
		    infoPanel.add(new JLabel("Căn hộ còn trống: " + availableApartments));
		    infoPanel.add(new JLabel("Căn hộ đã cho thuê: " + unavailableApartments));
		    infoPanel.add(new JLabel("Tổng tiền thuê: " + numberFormat.format(totalRent) + " VND"));
		    infoPanel.add(new JLabel("Giá thuê trung bình: " + numberFormat.format(avgRent) + " VND"));
		    infoPanel.add(new JLabel("Giá thuê cao nhất: " + numberFormat.format(maxRent) + " VND"));
		    infoPanel.add(new JLabel("Giá thuê thấp nhất: " + numberFormat.format(minRent) + " VND"));

		    // Biểu đồ tròn thể hiện tình trạng căn hộ
		    DefaultPieDataset dataset = new DefaultPieDataset();
		    dataset.setValue("Còn trống", availableApartments);
		    dataset.setValue("Đã cho thuê", unavailableApartments);

		    JFreeChart pieChart = ChartFactory.createPieChart(
		        "Tình trạng căn hộ", 
		        dataset, 
		        true, 
		        true, 
		        false
		    );

		    ChartPanel pieChartPanel = new ChartPanel(pieChart);

		    // Biểu đồ cột thể hiện giá thuê
		    DefaultCategoryDataset barDataset = new DefaultCategoryDataset();
		    barDataset.addValue(totalRent, "Tổng tiền", "Tổng tiền thuê");
		    barDataset.addValue(avgRent, "Trung bình", "Giá thuê TB");
		    barDataset.addValue(maxRent, "Cao nhất", "Giá thuê cao nhất");
		    barDataset.addValue(minRent, "Thấp nhất", "Giá thuê thấp nhất");

		    JFreeChart barChart = ChartFactory.createBarChart(
		        "Thống kê giá thuê",
		        "Loại",
		        "Giá (VND)",
		        barDataset,
		        PlotOrientation.VERTICAL,
		        true, true, false
		    );

		    ChartPanel barChartPanel = new ChartPanel(barChart);

		    // Thêm các panel vào dialog
		    statisticsDialog.add(infoPanel, BorderLayout.NORTH);
		    statisticsDialog.add(pieChartPanel, BorderLayout.CENTER);
		    statisticsDialog.add(barChartPanel, BorderLayout.SOUTH);

		    statisticsDialog.setLocationRelativeTo(this);
		    statisticsDialog.setVisible(true);
		}
		
		private void exportToPDF() {
		    // Chọn vị trí lưu tệp PDF
		    JFileChooser fileChooser = new JFileChooser();
		    fileChooser.setDialogTitle("Chọn vị trí để lưu tệp PDF");
		    int userSelection = fileChooser.showSaveDialog(this);
		    
		    if (userSelection == JFileChooser.APPROVE_OPTION) {
		        File fileToSave = fileChooser.getSelectedFile();
		        
		        // Tạo tài liệu PDF
		        Document document = new Document();
		        try {
		            PdfWriter.getInstance(document, new FileOutputStream(fileToSave));
		            document.open();
		            document.add(new Paragraph("Danh sách căn hộ"));
		            document.add(new Paragraph(" ")); // Thêm một khoảng trống

		            // Tạo bảng để hiển thị thông tin căn hộ
		            PdfPTable table = new PdfPTable(8); // Số cột trong bảng
		            table.addCell("Tòa nhà");
		            table.addCell("Căn hộ");
		            table.addCell("Diện tích m2");
		            table.addCell("Tiện nghi");
		            table.addCell("Dịch vụ tiện ích đi kèm");
		            table.addCell("Giá thuê (vnd)");
		            table.addCell("Thông tin người thuê");
		            table.addCell("Tình trạng");

		            // Lấy danh sách căn hộ và thêm vào bảng
		            List<Apartment> apartments = apartmentDao.getListApartments();
		            for (Apartment apartment : apartments) {
		                table.addCell(String.valueOf(apartment.getToaNha()));
		                table.addCell(apartment.getCanHo());
		                table.addCell(String.valueOf(apartment.getDienTich()));
		                table.addCell(apartment.getLuaChon_tienIch());
		                table.addCell(apartment.getLuaChon_dichVu() != null ? apartment.getLuaChon_dichVu() : "");
		                table.addCell(numberFormat.format(apartment.getGiaTien()));
		                table.addCell(apartment.getThongTinNguoiThue());
		                table.addCell(apartment.isTinhTrang() ? "Còn" : "Hết");
		            }

		            document.add(table);
		            JOptionPane.showMessageDialog(this, "Xuất PDF thành công!", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
		        } catch (Exception e) {
		            JOptionPane.showMessageDialog(this, "Lỗi khi xuất PDF: " + e.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
		        } finally {
		            document.close();
		        }
		    }
		}

		
		
		
		
		
}
