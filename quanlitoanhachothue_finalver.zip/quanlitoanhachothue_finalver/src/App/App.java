package App;

import javax.swing.*;

import controller.LoginController;
import view.ApartmentView;
import view.LoginView;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class App {

    public static void main(String[] args) {
        // Khởi động giao diện đăng nhập
        LoginView loginView = new LoginView();
        LoginController controller = new LoginController(loginView);
        
        

        // Hiển thị giao diện đăng nhập
        controller.showLoginView();
    }

    
   
}