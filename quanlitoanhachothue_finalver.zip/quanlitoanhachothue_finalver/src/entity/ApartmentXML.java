package entity;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
 
@XmlRootElement(name = "apartments")
@XmlAccessorType(XmlAccessType.FIELD)
public class ApartmentXML {
     
    private List<Apartment> apartment;
 
    public List<Apartment> getApartment() {
        return apartment;
    }
 
    public void setApartment(List<Apartment> apartments) {
        this.apartment = apartments;
    }
}