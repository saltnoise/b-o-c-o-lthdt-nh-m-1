package entity;

import java.io.Serializable;
import java.util.Objects;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
 
@XmlRootElement(name = "apartment")
@XmlAccessorType(XmlAccessType.FIELD)
public class Apartment implements Serializable {
    private static final long serialVersionUID = 1L;
    private int ToaNha;
    private String CanHo;
    private double DienTich;
    private String luaChon_tienIch;
    private String luaChon_dichVu;
    private double giaTien;
    private String thongTinNguoiThue;
    private boolean tinhTrang;
	public Apartment() {
		this.luaChon_dichVu = "";
		this.luaChon_tienIch = "";
		this.thongTinNguoiThue = "";
		this.tinhTrang = false;
		this.giaTien = 0.0;
		this.CanHo = "";
	}
	
	
	
	
	public Apartment(int toaNha, String canHo, double dienTich, String luaChon_tienIch, String luaChon_dichVu,
			double giaTien, String thongTinNguoiThue, boolean tinhTrang) {
		
		this.ToaNha = toaNha;
		this.CanHo = canHo;
		DienTich = dienTich;
		this.luaChon_tienIch = luaChon_tienIch;
		this.luaChon_dichVu = luaChon_dichVu;
		this.giaTien = giaTien;
		this.thongTinNguoiThue = thongTinNguoiThue;
		this.tinhTrang = tinhTrang;
	}




	




	public Apartment(int toaNha, String canHo) {
		super();
		ToaNha = toaNha;
		CanHo = canHo;
	}



	
	




	public int getToaNha() {
		return ToaNha;
	}
	public void setToaNha(int toaNha) {
		ToaNha = toaNha;
	}
	public String getCanHo() {
		return CanHo;
	}
	public void setCanHo(String canHo) {
		CanHo = canHo;
	}
	public double getDienTich() {
		return DienTich;
	}
	public void setDienTich(double dienTich) {
		DienTich = dienTich;
	}
	public String getLuaChon_tienIch() {
		return luaChon_tienIch;
	}
	public void setLuaChon_tienIch(String luaChon_tienIch) {
		this.luaChon_tienIch = luaChon_tienIch;
	}
	public String getLuaChon_dichVu() {
		return luaChon_dichVu;
	}
	public void setLuaChon_dichVu(String luaChon_dichVu) {
		this.luaChon_dichVu = luaChon_dichVu;
	}
	public double getGiaTien() {
		return giaTien;
	}
	public void setGiaTien(double giaTien) {
		this.giaTien = giaTien;
	}
	public String getThongTinNguoiThue() {
		return thongTinNguoiThue;
	}
	public void setThongTinNguoiThue(String thongTinNguoiThue) {
		this.thongTinNguoiThue = thongTinNguoiThue;
	}
	public boolean isTinhTrang() {
		return tinhTrang;
	}
	public void setTinhTrang(boolean tinhTrang) {
		this.tinhTrang = tinhTrang;
	}




	@Override
	public int hashCode() {
		return Objects.hash(CanHo, DienTich, ToaNha, giaTien, luaChon_dichVu, luaChon_tienIch, thongTinNguoiThue,
				tinhTrang);
	}




	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Apartment other = (Apartment) obj;
		return Objects.equals(CanHo, other.CanHo)
				&& Double.doubleToLongBits(DienTich) == Double.doubleToLongBits(other.DienTich)
				&& ToaNha == other.ToaNha && Double.doubleToLongBits(giaTien) == Double.doubleToLongBits(other.giaTien)
				&& Objects.equals(luaChon_dichVu, other.luaChon_dichVu)
				&& Objects.equals(luaChon_tienIch, other.luaChon_tienIch)
				&& Objects.equals(thongTinNguoiThue, other.thongTinNguoiThue) && tinhTrang == other.tinhTrang;
	}
	
	
	
	
	
    
    
    
    
    
   
 
   
 
}